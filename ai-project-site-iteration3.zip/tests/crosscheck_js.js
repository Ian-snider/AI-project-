// Checker, cross-implementation part. Run: node tests/crosscheck_js.js
// The browser solver must reproduce the Python reference core
// (tests/test_vectors.json) on every library example, and match the
// laminar known-answer case on its own.
"use strict";
const fs = require("fs");
const solver = require("../solver.js");
const ex = require("../examples.js");
global.PUMPS = ex.PUMPS; // buildInputs reads the shared pump table

const vectors = JSON.parse(fs.readFileSync("tests/test_vectors.json", "utf8"));
let fails = 0;
function cmp(label, jsRes, pyRes) {
  let worstQ = 0, worstH = 0;
  jsRes.pipes.forEach((p, i) => {
    const py = pyRes.pipes[i].Q;
    const rel = Math.abs(p.Q - py) / Math.max(Math.abs(py), 1e-12);
    if (rel > worstQ) worstQ = rel;
  });
  for (const k of Object.keys(pyRes.heads)) {
    const d = Math.abs(jsRes.heads[k] - pyRes.heads[k]);
    if (d > worstH) worstH = d;
  }
  const ok = worstQ < 1e-6 && worstH < 1e-6 && jsRes.converged;
  console.log((ok ? "PASS " : "FAIL ") + label +
    "  worst flow rel diff " + worstQ.toExponential(2) +
    ", worst head diff " + worstH.toExponential(2) + " m");
  if (!ok) fails++;
}

for (const key of Object.keys(ex.EXAMPLES)) {
  const e = ex.EXAMPLES[key];
  const fl = ex.FLUIDS[e.fluid];
  const inp = solver.buildInputs(e.nodes, e.pipes);
  cmp("example " + key, solver.solveNetwork(inp.nodes, inp.pipes, fl.rho, fl.mu),
      vectors.examples[key]);
}

const lam = solver.solveNetwork({ tank: 10, sink: 0 },
  [{ name: "p", a: "tank", b: "sink", D: 0.05, L: 50, eps: 1e-5, K: 0, pump: null }], 900, 0.5);
const qHP = Math.PI * Math.pow(0.05, 4) * 900 * 9.81 * 10 / (128 * 0.5 * 50);
const ratio = lam.pipes[0].Q / qHP;
const okL = Math.abs(ratio - 1) < 0.002;
console.log((okL ? "PASS " : "FAIL ") + "JS laminar = Hagen-Poiseuille  ratio " + ratio.toFixed(4));
if (!okL) fails++;

console.log("RESULT:", fails === 0 ? "ALL PASS" : fails + " FAILURES");
process.exit(fails ? 1 : 0);
