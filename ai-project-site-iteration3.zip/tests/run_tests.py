# Checker, calculation part. Run: python3 tests/run_tests.py
# Writes tests/test_vectors.json, which the website solver must reproduce.
import json
import sys

import numpy as np

sys.path.insert(0, "core")
from network import FLUIDS, PRESET_NODES, preset_pipes, solve

fails = []


def check(label, ok, detail):
    print(("PASS " if ok else "FAIL ") + label + "  " + detail)
    if not ok:
        fails.append(label)


# T1 - laminar single pipe against Hagen-Poiseuille [CLASS Weeks 5-7]:
# Q = pi * D^4 * rho * g * dH / (128 * mu * L), all symbols as in core/network.py
rho, mu, D, L, dH = 900.0, 0.5, 0.05, 50.0, 10.0
r = solve({"tank": dH, "sink": 0.0},
          [{"name": "p", "a": "tank", "b": "sink", "D": D, "L": L,
            "eps": 1e-5, "K": 0.0, "pump": None}], rho, mu)
q_hp = np.pi * D ** 4 * rho * 9.81 * dH / (128 * mu * L)
ratio = r["pipes"][0]["Q"] / q_hp
check("T1 laminar = Hagen-Poiseuille", abs(ratio - 1) < 0.002,
      f"solver {r['pipes'][0]['Q']:.6f}, analytic {q_hp:.6f}, ratio {ratio:.4f}")

# T2 - preset network, crude: balance, directions, ordering
crude = FLUIDS["Crude oil (preset)"]
r2 = solve(PRESET_NODES, preset_pipes(), crude["rho"], crude["mu"])
qs = [p["Q"] for p in r2["pipes"]]
check("T2 preset converges and balances", r2["ier"] == 1 and r2["max_residual"] < 1e-8,
      f"ier {r2['ier']}, max residual {r2['max_residual']:.1e}")
check("T2 all flows forward", all(q > 0 for q in qs), f"flows {[round(q, 4) for q in qs]}")
check("T2 high tank feeds more than low tank", qs[0] > qs[1], f"{qs[0]:.4f} > {qs[1]:.4f}")
check("T2 low unit draws more than high unit", qs[4] > qs[3], f"{qs[4]:.4f} > {qs[3]:.4f}")

# T3 - stress network: 10 pipes, 4 pumps (the group's example size)
P = {"H0": 35.0, "kp": 900.0, "s": 1.0, "eta": 0.75}
nodes3 = {"In1": 28.0, "In2": 18.0, "J1": None, "J2": None, "J3": None,
          "Out1": 20.0, "Out2": 12.0, "Out3": 16.0, "Out4": 6.0}


def pipe(name, a, b, D, L, K, pump=None):
    return {"name": name, "a": a, "b": b, "D": D, "L": L, "eps": 4.5e-5, "K": K, "pump": pump}


pipes3 = [pipe("p1", "In1", "J1", 0.20, 100.0, 1.25), pipe("p2", "In2", "J1", 0.20, 80.0, 0.95),
          pipe("p3", "J1", "J2", 0.25, 150.0, 2.95, P), pipe("p4", "J2", "Out1", 0.15, 120.0, 2.55),
          pipe("p5", "J2", "J3", 0.20, 90.0, 0.3, P), pipe("p6", "J3", "Out2", 0.15, 100.0, 2.25),
          pipe("p7", "J3", "Out3", 0.15, 140.0, 2.95, P), pipe("p8", "J1", "J3", 0.15, 200.0, 3.0),
          pipe("p9", "J2", "Out4", 0.15, 70.0, 2.95, P), pipe("p10", "In1", "J2", 0.15, 250.0, 3.5)]
r3 = solve(nodes3, pipes3, crude["rho"], crude["mu"])
check("T3 stress 10 pipes / 4 pumps converges", r3["ier"] == 1 and r3["max_residual"] < 1e-7,
      f"ier {r3['ier']}, max residual {r3['max_residual']:.1e}")

# T4 - reversal is flagged, not hidden: raise Unit 2 head above the split head
nodes4 = dict(PRESET_NODES)
nodes4["Unit 2"] = 60.0
r4 = solve(nodes4, preset_pipes(), crude["rho"], crude["mu"])
check("T4 reversed branch flagged", r4["pipes"][4]["reversed"],
      f"Pipe 5 flow {r4['pipes'][4]['Q']:.4f} (negative expected)")

# T5 - water check case solves and runs faster than crude in the trunk
water = FLUIDS["Water, 20 C (check case)"]
r5 = solve(PRESET_NODES, preset_pipes(), water["rho"], water["mu"])
check("T5 water trunk flow exceeds crude trunk flow", r5["pipes"][2]["Q"] > qs[2],
      f"water {r5['pipes'][2]['Q']:.4f} > crude {qs[2]:.4f}")

# ---- E1-E5: the use-case library (mirrors examples.js) ----
def N(name, head):
    return (name, head)

def ex_pipe(name, a, b, D, L, K, pump_name=None, s=1.0):
    pump = None
    if pump_name:
        pump = dict(PUMPS[pump_name]); pump["s"] = s
    return {"name": name, "a": a, "b": b, "D": D, "L": L, "eps": STEEL_EPS, "K": K, "pump": pump}

from network import PUMPS, STEEL_EPS
oil = FLUIDS["Viscous oil (preset)"]
EXAMPLES_PY = {
    "refinery": (PRESET_NODES, preset_pipes(), crude),
    "parallel": ({"Tank High": 30.0, "Tank Low": 10.0},
                 [ex_pipe("Pipe 1", "Tank High", "Tank Low", 0.10, 100.0, 1.0),
                  ex_pipe("Pipe 2", "Tank High", "Tank Low", 0.15, 100.0, 1.0)], water),
    "gravity": ({"Roof Tank": 40.0, "Junction J": None, "High Outlet": 15.0, "Low Outlet": 5.0},
                [ex_pipe("Pipe 1", "Roof Tank", "Junction J", 0.12, 60.0, 1.5),
                 ex_pipe("Pipe 2", "Junction J", "High Outlet", 0.08, 40.0, 2.0),
                 ex_pipe("Pipe 3", "Junction J", "Low Outlet", 0.08, 30.0, 2.0)], water),
    "starved": ({"Supply Tank": 10.0, "Junction J": None, "High Unit": 34.0, "Low Unit": 12.0},
                [ex_pipe("Pipe 1", "Supply Tank", "Junction J", 0.15, 80.0, 1.5, "Pump W (weak)"),
                 ex_pipe("Pipe 2", "Junction J", "High Unit", 0.10, 60.0, 2.0),
                 ex_pipe("Pipe 3", "Junction J", "Low Unit", 0.10, 60.0, 2.0)], crude),
    "laminar": ({"Tank A": 14.0, "Middle M": None, "Tank B": 10.0},
                [ex_pipe("Pipe 1", "Tank A", "Middle M", 0.06, 40.0, 0.5),
                 ex_pipe("Pipe 2", "Middle M", "Tank B", 0.06, 60.0, 0.5)], oil),
    "topfill": ({"Source A": 14.0, "Source B": 11.0, "Junction J": None, "Receiving Tank": 21.0},
                [ex_pipe("A Feed", "Source A", "Junction J", 0.12, 90.0, 1.2),
                 ex_pipe("B Feed", "Source B", "Junction J", 0.12, 110.0, 1.2),
                 ex_pipe("Fill Line", "Junction J", "Receiving Tank", 0.15, 160.0, 2.45, "Pump L (loading)")], crude),
}
ex_res = {}
for key, (nd, pp, fl) in EXAMPLES_PY.items():
    ex_res[key] = solve(nd, pp, fl["rho"], fl["mu"])
    no_free = all(v is not None for v in nd.values())
    check(f"E-{key} converges and balances",
          (ex_res[key]["ier"] == 1 or no_free) and ex_res[key]["max_residual"] < 1e-7,
          f"max residual {ex_res[key]['max_residual']:.1e}")

ratio2 = ex_res["parallel"]["pipes"][1]["Q"] / ex_res["parallel"]["pipes"][0]["Q"]
check("E2 parallel split ratio in (2.5, 3.2)", 2.5 < ratio2 < 3.2, f"ratio {ratio2:.2f}")
check("E3 low outlet draws more than high outlet",
      ex_res["gravity"]["pipes"][2]["Q"] > ex_res["gravity"]["pipes"][1]["Q"],
      f"{ex_res['gravity']['pipes'][2]['Q']:.4f} > {ex_res['gravity']['pipes'][1]['Q']:.4f}")
check("E4 high branch starved at speed 1 (reversed)",
      ex_res["starved"]["pipes"][1]["Q"] < 0,
      f"Pipe 2 flow {ex_res['starved']['pipes'][1]['Q']:.4f}")
nd4, pp4, fl4 = EXAMPLES_PY["starved"]
pp4b = [dict(p) for p in pp4]
pp4b[0] = dict(pp4[0]); pp4b[0]["pump"] = dict(pp4[0]["pump"]); pp4b[0]["pump"]["s"] = 1.3
r4b = solve(nd4, pp4b, fl4["rho"], fl4["mu"])
check("E4 speed 1.3 rescues the high branch", r4b["pipes"][1]["Q"] > 0.02,
      f"Pipe 2 flow {r4b['pipes'][1]['Q']:.4f}")
a5 = 32 * oil["mu"] * 100.0 / (oil["rho"] * 9.81 * 0.06 ** 2)
b5 = 1.0 / (2 * 9.81)
V5 = (-a5 + np.sqrt(a5 ** 2 + 4 * b5 * 4.0)) / (2 * b5)
q5 = V5 * np.pi * 0.06 ** 2 / 4
check("E5 laminar series matches hand result", abs(ex_res["laminar"]["pipes"][0]["Q"] / q5 - 1) < 0.005,
      f"solver {ex_res['laminar']['pipes'][0]['Q']:.6f}, analytic {q5:.6f}, Re {ex_res['laminar']['pipes'][0]['Re']:.1f}")
tf = ex_res["topfill"]["pipes"]
check("E6 both source tanks feed forward", tf[0]["Q"] > 0 and tf[1]["Q"] > 0,
      f"A {tf[0]['Q']:.4f}, B {tf[1]['Q']:.4f}")
check("E6 fill flow equals the two feeds combined", abs(tf[2]["Q"] - (tf[0]["Q"] + tf[1]["Q"])) < 1e-9,
      f"fill {tf[2]['Q']:.4f} = A + B {tf[0]['Q'] + tf[1]['Q']:.4f}")
vol6 = np.pi * 3.0 ** 2 / 4 * (5.2 - 1.0)
t6 = vol6 / tf[2]["Q"] / 60
check("E6 top-fill time to max level in (15, 20) min", 15 < t6 < 20,
      f"volume {vol6:.1f} m3, flow {tf[2]['Q']:.4f} m3/s, time {t6:.1f} min, V {tf[2]['V']:.2f} m/s")

vectors = {"preset_crude": r2, "preset_water": r5, "examples": ex_res,
           "inputs": {"nodes": PRESET_NODES, "fluids": FLUIDS}}
with open("tests/test_vectors.json", "w") as fh:
    json.dump(vectors, fh, indent=1)
print("test vectors written:", "tests/test_vectors.json")
print("RESULT:", "ALL PASS" if not fails else f"{len(fails)} FAILURES: {fails}")
sys.exit(1 if fails else 0)
